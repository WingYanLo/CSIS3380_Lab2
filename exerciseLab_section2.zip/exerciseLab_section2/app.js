const express = require('express')
// const req = require('express/lib/request')
const app = express()

app.use(express.json() )
app.use(express.urlencoded({extended: true}))

app.get('/register', (req, res) => {
    res.sendFile(__dirname + "/form.html")
})

app.post('/', (req, res) => {
    res.send(`<h1 style="color: red">Hello ${req.body.user} </h1> 
    <br>
    <h3> Your password is ${req.body.password} </h3>`)
})

app.get('*', (req, res) => {
    res.send(`<h1 style="color: red; text-align: center;">Page Not Found</h1>`)
})

app.listen(5000, () => {
    console.log('server on 5000')
})
